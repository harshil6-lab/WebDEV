// Password Strength Meter
document.getElementById('password').addEventListener('input', function () {
  const pwd = this.value;
  const msg = document.getElementById('strengthMessage');

  let strength = 0;
  if (pwd.length >= 6) strength++;
  if (/[a-z]/.test(pwd)) strength++;
  if (/[A-Z]/.test(pwd)) strength++;
  if (/[0-9]/.test(pwd)) strength++;
  if (/[\W_]/.test(pwd)) strength++;

  let level = '';
  let color = '';

  if (strength <= 2) {
    level = 'Weak';
    color = 'red';
  } else if (strength === 3 || strength === 4) {
    level = 'Medium';
    color = 'orange';
  } else {
    level = 'Strong';
    color = 'green';
  }

  msg.textContent = `Password Strength: ${level}`;
  msg.style.color = color;
});

// Form Submit Handler
document.getElementById('registrationForm').addEventListener('submit', function (e) {
  e.preventDefault(); // Prevent actual form submission

  // Get all form values
  const name = document.getElementById('fullname').value;
  const email = document.getElementById('email').value;
  const age = document.getElementById('age').value;
  const password = document.getElementById('password').value;
  const gender = document.getElementById('gender').value;

  // Display Data
  const output = `
    <h3>Submitted Data:</h3>
    <p><strong>Full Name:</strong> ${name}</p>
    <p><strong>Email:</strong> ${email}</p>
    <p><strong>Age:</strong> ${age}</p>
    <p><strong>Gender:</strong> ${gender}</p>
  `;

  document.getElementById('submittedData').innerHTML = output;

  // Optionally clear the form
  this.reset();
  document.getElementById('strengthMessage').textContent = 'Password Strength: ';
});
